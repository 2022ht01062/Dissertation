/***************************** Include Files *********************************/
#include <stdio.h>
#include "platform.h"
#include "xspi.h"





/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */




void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount);
int spi_lb_test(void);
int spi_flash_write(void);
int spi_flash_read(void);
