#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xuartns550_l.h"
 #define UART_BAUD 115200

void init_uart();
int uart_recieve_fw();
