

#include <stdint.h>

void AES_Decrypt(uint8_t* input, uint8_t* output, uint8_t* key);
void create_key_from_id(const char *id_string, unsigned char *key);
size_t remove_padding(uint8_t *data, size_t data_len);
