#ifndef __PLATFORM_CONFIG_H_
#define __PLATFORM_CONFIG_H_

#include "xgpio.h"
#include "xuartns550.h"
#include "spi_api.h"
#include "uart_api.h"
#include "xspi.h"		/* SPI device driver */



#define STDOUT_IS_16550
#define STDOUT_BASEADDR XPAR_AXI_UART16550_0_BASEADDR
#define SPI_DEVICE_ID			XPAR_SPI_0_DEVICE_ID
#define SPI_SELECT 			0x01



#define USER_LED0 1
#define BOOT_STRAP 1
#define USER_LED1 2
#define GPIO_INPUT 1
#define GPIO_OUTPUT 0
#define USR_LED_CHL 1
#define AP_RESET_CHL 2
#define BOOT_STRAP_CHL 1
// Define a pointer to the start of the custom memory region
#define MY_REGION_START ((uint8_t *)0xC2000020)
#define MY_REGION_SIZE  0x10000


void *allocate_memory(size_t size);
int uart_recieve_fw();
#endif
