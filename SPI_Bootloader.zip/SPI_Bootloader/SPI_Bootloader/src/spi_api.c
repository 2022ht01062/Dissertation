/************************** Include Files *****************************/
#include "spi_api.h"

#include <stdio.h>
#include "platform.h"
#include "xspi.h"
#include "spi_flash_drv.h"


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */

/*
 * Byte offset value written to Flash. This needs to be redefined for writing
 * different patterns of data to the Flash device.
 */
static XSpi Spi;
extern u32 fw_size;
extern u8 *uart_rx_buf;
u8 ReadBuffer[PAGE_SIZE];
u8 WriteBuffer[PAGE_SIZE];
/************************** Test Definitions *****************************/

void init_spi()
{
	int Status;
	u32 Data;
	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */
	/*
	 * Initialize the SPI driver so that it's ready to use,
	 * specify the device ID that is generated in xparameters.h.
	 */
	if(Spi.IsStarted != XIL_COMPONENT_IS_STARTED)
	{
		ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
		if (ConfigPtr == NULL) {
			return XST_DEVICE_NOT_FOUND;
		}

		Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
					  ConfigPtr->BaseAddress);
		if(Status == XST_SUCCESS)
			print(" SPI Initialization Success \r\n");
		else
			print(" SPI Initialization Failed \r\n");

		Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION );
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = XSpi_SetSlaveSelect(&Spi, SPI_SELECT);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}


		 Spi.IsStarted = XIL_COMPONENT_IS_STARTED;

		 /* Reset the transmit and receive FIFOs if present. There is a critical
		 * section here since this register is also modified during interrupt
		 * context. So we wait until after the r/m/w of the control register to
		 * enable the Global Interrupt Enable.*/

		Data = XSpi_GetControlReg(&Spi);
		Data |= XSP_CR_TXFIFO_RESET_MASK | XSP_CR_RXFIFO_RESET_MASK |
				XSP_CR_ENABLE_MASK;
		XSpi_SetControlReg(&Spi, Data);
	}
}



int spi_flash_write(void)
{
	int Status;
	u32 Index;

	/*
	 * Perform the Write Enable operation.
	 */
	Status = SpiFlashWriteEnable(&Spi);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Write Enable Command Issued \r\n");

	/*
	 * Perform the Sector Erase operation.
	 */
	Status = SpiFlashSectorErase(&Spi, FLASH_TEST_ADDRESS);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Sector Erase Command Issued \r\n");

	Status = Is_FlashReady(&Spi);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Sector Erase Completed \r\n");

	/*
	 * Write the data to the Page using Page Program command.
	 */
	Status = SpiFlashWrite(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_PAGE_PROGRAM);
	if(Status == XST_SUCCESS)
			print(" Firmware written into Flash \r\n");

	Status = SpiFlashKeywordWrite(&Spi);
		if(Status == XST_SUCCESS)
				print(" Keyword written into Flash \r\n");

	/*
	 * Read the data from the Page using Random Read command.
	 */
	Status = SpiFlashRead(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_RANDOM_READ);
	if(Status == XST_SUCCESS)
			print(" Firmware Read back from Flash \r\n");

	for(Index = 0;Index < fw_size; Index++)
	{
		if(*uart_rx_buf != *(uart_rx_buf+25600))
			return XST_FAILURE;
	}
	print(" Firmware Integrity Check Pass \r\n");
	return XST_SUCCESS;
}


int spi_flash_read(void)
{
	int Status;
	u32 Keyword;
	Status = Is_FlashReady(&Spi);
		if(Status == XST_SUCCESS)
			print(" SPI Flash Ready \r\n");

	SpiFlashKeywordRead(&Spi, &fw_size, &Keyword);//SpiFlashKeywordRead(&Spi);
		if(Keyword != FLASH_KEYWORD)
		{
			print(" Invalid Keyword Read from Flash \r\n");
			return XST_FAILURE;
		}
	Status = SpiFlashRead(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_RANDOM_READ);

	return Status;
}
